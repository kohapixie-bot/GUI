﻿namespace Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.delete = new System.Windows.Forms.Button();
            this.cancel = new System.Windows.Forms.Button();
            this.percentage = new System.Windows.Forms.Button();
            this.square = new System.Windows.Forms.Button();
            this.button_add = new System.Windows.Forms.Button();
            this.button_sub = new System.Windows.Forms.Button();
            this.button_multi = new System.Windows.Forms.Button();
            this.button_divide = new System.Windows.Forms.Button();
            this.button_nine = new System.Windows.Forms.Button();
            this.button_eight = new System.Windows.Forms.Button();
            this.button_seven = new System.Windows.Forms.Button();
            this.button_six = new System.Windows.Forms.Button();
            this.button_five = new System.Windows.Forms.Button();
            this.button_four = new System.Windows.Forms.Button();
            this.button_one = new System.Windows.Forms.Button();
            this.button_three = new System.Windows.Forms.Button();
            this.button_two = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button_equal = new System.Windows.Forms.Button();
            this.button_dot = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.answer_display = new System.Windows.Forms.Label();
            this.expression = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel1.Controls.Add(this.delete);
            this.panel1.Controls.Add(this.cancel);
            this.panel1.Controls.Add(this.percentage);
            this.panel1.Controls.Add(this.square);
            this.panel1.Controls.Add(this.button_add);
            this.panel1.Controls.Add(this.button_sub);
            this.panel1.Controls.Add(this.button_multi);
            this.panel1.Controls.Add(this.button_divide);
            this.panel1.Controls.Add(this.button_nine);
            this.panel1.Controls.Add(this.button_eight);
            this.panel1.Controls.Add(this.button_seven);
            this.panel1.Controls.Add(this.button_six);
            this.panel1.Controls.Add(this.button_five);
            this.panel1.Controls.Add(this.button_four);
            this.panel1.Controls.Add(this.button_one);
            this.panel1.Controls.Add(this.button_three);
            this.panel1.Controls.Add(this.button_two);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button_equal);
            this.panel1.Controls.Add(this.button_dot);
            this.panel1.Location = new System.Drawing.Point(42, 147);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(433, 368);
            this.panel1.TabIndex = 0;
            // 
            // delete
            // 
            this.delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.delete.Location = new System.Drawing.Point(326, 47);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(79, 56);
            this.delete.TabIndex = 19;
            this.delete.Text = "Del";
            this.delete.UseVisualStyleBackColor = true;
            this.delete.Click += new System.EventHandler(this.delete_Click);
            // 
            // cancel
            // 
            this.cancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancel.Location = new System.Drawing.Point(229, 47);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(79, 56);
            this.cancel.TabIndex = 18;
            this.cancel.Text = "CE";
            this.cancel.UseVisualStyleBackColor = true;
            this.cancel.Click += new System.EventHandler(this.cancel_Click);
            // 
            // percentage
            // 
            this.percentage.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.percentage.Location = new System.Drawing.Point(127, 47);
            this.percentage.Name = "percentage";
            this.percentage.Size = new System.Drawing.Size(79, 56);
            this.percentage.TabIndex = 17;
            this.percentage.Text = "%";
            this.percentage.UseVisualStyleBackColor = true;
            this.percentage.Click += new System.EventHandler(this.percentage_Click);
            // 
            // square
            // 
            this.square.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.square.Location = new System.Drawing.Point(24, 47);
            this.square.Name = "square";
            this.square.Size = new System.Drawing.Size(79, 56);
            this.square.TabIndex = 16;
            this.square.Text = "x^2";
            this.square.UseVisualStyleBackColor = true;
            this.square.Click += new System.EventHandler(this.square_Click);
            // 
            // button_add
            // 
            this.button_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_add.Location = new System.Drawing.Point(326, 295);
            this.button_add.Name = "button_add";
            this.button_add.Size = new System.Drawing.Size(79, 56);
            this.button_add.TabIndex = 15;
            this.button_add.Text = "+";
            this.button_add.UseVisualStyleBackColor = true;
            this.button_add.Click += new System.EventHandler(this.button_add_Click);
            // 
            // button_sub
            // 
            this.button_sub.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_sub.Location = new System.Drawing.Point(326, 233);
            this.button_sub.Name = "button_sub";
            this.button_sub.Size = new System.Drawing.Size(79, 56);
            this.button_sub.TabIndex = 14;
            this.button_sub.Text = "-";
            this.button_sub.UseVisualStyleBackColor = true;
            this.button_sub.Click += new System.EventHandler(this.button_sub_Click);
            // 
            // button_multi
            // 
            this.button_multi.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_multi.Location = new System.Drawing.Point(326, 171);
            this.button_multi.Name = "button_multi";
            this.button_multi.Size = new System.Drawing.Size(79, 56);
            this.button_multi.TabIndex = 13;
            this.button_multi.Text = "x";
            this.button_multi.UseVisualStyleBackColor = true;
            this.button_multi.Click += new System.EventHandler(this.button_multi_Click);
            // 
            // button_divide
            // 
            this.button_divide.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_divide.Location = new System.Drawing.Point(326, 109);
            this.button_divide.Name = "button_divide";
            this.button_divide.Size = new System.Drawing.Size(79, 56);
            this.button_divide.TabIndex = 12;
            this.button_divide.Text = "/";
            this.button_divide.UseVisualStyleBackColor = true;
            this.button_divide.Click += new System.EventHandler(this.button_divide_Click);
            // 
            // button_nine
            // 
            this.button_nine.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_nine.Location = new System.Drawing.Point(229, 109);
            this.button_nine.Name = "button_nine";
            this.button_nine.Size = new System.Drawing.Size(79, 56);
            this.button_nine.TabIndex = 11;
            this.button_nine.Text = "9";
            this.button_nine.UseVisualStyleBackColor = true;
            this.button_nine.Click += new System.EventHandler(this.button_nine_Click);
            // 
            // button_eight
            // 
            this.button_eight.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_eight.Location = new System.Drawing.Point(127, 109);
            this.button_eight.Name = "button_eight";
            this.button_eight.Size = new System.Drawing.Size(79, 56);
            this.button_eight.TabIndex = 10;
            this.button_eight.Text = "8";
            this.button_eight.UseVisualStyleBackColor = true;
            this.button_eight.Click += new System.EventHandler(this.button_eight_Click);
            // 
            // button_seven
            // 
            this.button_seven.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_seven.Location = new System.Drawing.Point(24, 109);
            this.button_seven.Name = "button_seven";
            this.button_seven.Size = new System.Drawing.Size(79, 56);
            this.button_seven.TabIndex = 9;
            this.button_seven.Text = "7";
            this.button_seven.UseVisualStyleBackColor = true;
            this.button_seven.Click += new System.EventHandler(this.button_seven_Click);
            // 
            // button_six
            // 
            this.button_six.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_six.ForeColor = System.Drawing.Color.Black;
            this.button_six.Location = new System.Drawing.Point(229, 171);
            this.button_six.Name = "button_six";
            this.button_six.Size = new System.Drawing.Size(79, 56);
            this.button_six.TabIndex = 8;
            this.button_six.Text = "6";
            this.button_six.UseVisualStyleBackColor = true;
            this.button_six.Click += new System.EventHandler(this.button9_Click);
            // 
            // button_five
            // 
            this.button_five.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_five.Location = new System.Drawing.Point(127, 171);
            this.button_five.Name = "button_five";
            this.button_five.Size = new System.Drawing.Size(79, 56);
            this.button_five.TabIndex = 7;
            this.button_five.Text = "5";
            this.button_five.UseVisualStyleBackColor = true;
            this.button_five.Click += new System.EventHandler(this.button8_Click);
            // 
            // button_four
            // 
            this.button_four.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_four.Location = new System.Drawing.Point(24, 171);
            this.button_four.Name = "button_four";
            this.button_four.Size = new System.Drawing.Size(79, 56);
            this.button_four.TabIndex = 6;
            this.button_four.Text = "4";
            this.button_four.UseVisualStyleBackColor = true;
            this.button_four.Click += new System.EventHandler(this.button7_Click);
            // 
            // button_one
            // 
            this.button_one.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_one.Location = new System.Drawing.Point(24, 233);
            this.button_one.Name = "button_one";
            this.button_one.Size = new System.Drawing.Size(79, 56);
            this.button_one.TabIndex = 5;
            this.button_one.Text = "1";
            this.button_one.UseVisualStyleBackColor = true;
            this.button_one.Click += new System.EventHandler(this.button6_Click);
            // 
            // button_three
            // 
            this.button_three.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_three.Location = new System.Drawing.Point(229, 233);
            this.button_three.Name = "button_three";
            this.button_three.Size = new System.Drawing.Size(79, 56);
            this.button_three.TabIndex = 4;
            this.button_three.Text = "3";
            this.button_three.UseVisualStyleBackColor = true;
            this.button_three.Click += new System.EventHandler(this.button_three_Click);
            // 
            // button_two
            // 
            this.button_two.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_two.Location = new System.Drawing.Point(127, 233);
            this.button_two.Name = "button_two";
            this.button_two.Size = new System.Drawing.Size(79, 56);
            this.button_two.TabIndex = 3;
            this.button_two.Text = "2";
            this.button_two.UseVisualStyleBackColor = true;
            this.button_two.Click += new System.EventHandler(this.button_two_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(127, 295);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(79, 56);
            this.button3.TabIndex = 2;
            this.button3.Text = "0";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button_equal
            // 
            this.button_equal.BackColor = System.Drawing.Color.Silver;
            this.button_equal.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_equal.Location = new System.Drawing.Point(229, 295);
            this.button_equal.Name = "button_equal";
            this.button_equal.Size = new System.Drawing.Size(79, 56);
            this.button_equal.TabIndex = 1;
            this.button_equal.Text = "=";
            this.button_equal.UseVisualStyleBackColor = false;
            this.button_equal.Click += new System.EventHandler(this.button_equal_Click);
            // 
            // button_dot
            // 
            this.button_dot.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_dot.Location = new System.Drawing.Point(24, 295);
            this.button_dot.Name = "button_dot";
            this.button_dot.Size = new System.Drawing.Size(79, 56);
            this.button_dot.TabIndex = 0;
            this.button_dot.Text = "•";
            this.button_dot.UseVisualStyleBackColor = true;
            this.button_dot.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel2.Controls.Add(this.answer_display);
            this.panel2.Controls.Add(this.expression);
            this.panel2.Location = new System.Drawing.Point(42, 23);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(433, 99);
            this.panel2.TabIndex = 1;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // answer_display
            // 
            this.answer_display.AutoSize = true;
            this.answer_display.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.answer_display.Location = new System.Drawing.Point(305, 65);
            this.answer_display.MinimumSize = new System.Drawing.Size(100, 0);
            this.answer_display.Name = "answer_display";
            this.answer_display.Size = new System.Drawing.Size(100, 26);
            this.answer_display.TabIndex = 1;
            this.answer_display.Text = "answer";
            // 
            // expression
            // 
            this.expression.AutoSize = true;
            this.expression.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.expression.Location = new System.Drawing.Point(8, 10);
            this.expression.MinimumSize = new System.Drawing.Size(300, 0);
            this.expression.Name = "expression";
            this.expression.Size = new System.Drawing.Size(300, 26);
            this.expression.TabIndex = 0;
            this.expression.Text = "exp";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Gray;
            this.panel3.Controls.Add(this.panel2);
            this.panel3.Controls.Add(this.panel1);
            this.panel3.Location = new System.Drawing.Point(51, 12);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(518, 543);
            this.panel3.TabIndex = 2;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(631, 582);
            this.Controls.Add(this.panel3);
            this.Name = "Form1";
            this.Text = "SimpleCalculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button_dot;
        private System.Windows.Forms.Button button_six;
        private System.Windows.Forms.Button button_five;
        private System.Windows.Forms.Button button_four;
        private System.Windows.Forms.Button button_one;
        private System.Windows.Forms.Button button_three;
        private System.Windows.Forms.Button button_two;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button_equal;
        private System.Windows.Forms.Button button_seven;
        private System.Windows.Forms.Button button_nine;
        private System.Windows.Forms.Button button_eight;
        private System.Windows.Forms.Button button_add;
        private System.Windows.Forms.Button button_sub;
        private System.Windows.Forms.Button button_multi;
        private System.Windows.Forms.Button button_divide;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.Button cancel;
        private System.Windows.Forms.Button percentage;
        private System.Windows.Forms.Button square;
        private System.Windows.Forms.Label answer_display;
        private System.Windows.Forms.Label expression;
        private System.Windows.Forms.Panel panel3;
    }
}

