﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Form1 : Form
    {
        double value_one;
        double value_two;
        char operator_name = ' ';
        string temporary_value = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void numberClick(string val)
        {
            expression.Text = expression.Text + val;
            temporary_value = temporary_value+val;
        }
        private void Operator_click(char op)
        {
            if (temporary_value.Equals(""))
            {
                return;
            }
            value_one = Convert.ToDouble(temporary_value);
            operator_name = op;
            temporary_value = " ";
            expression.Text = expression.Text + op;

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            expression.Text = "";
            answer_display.Text = "";
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            numberClick(".");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            numberClick("4");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            numberClick("5");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            numberClick("6");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            numberClick("1");
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void button_eight_Click(object sender, EventArgs e)
        {
            numberClick("8");

        }

        private void button_two_Click(object sender, EventArgs e)
        {
            numberClick("2");

        }

        private void button_three_Click(object sender, EventArgs e)
        {
            numberClick("3");
        }

        private void button_seven_Click(object sender, EventArgs e)
        {
            numberClick("7");
        }

        private void button_nine_Click(object sender, EventArgs e)
        {
            numberClick("9");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            numberClick("0");
        }

        private void button_add_Click(object sender, EventArgs e)
        {
            Operator_click('+');


        }

        private void button_sub_Click(object sender, EventArgs e)
        {
            Operator_click('-');
        }

        private void button_multi_Click(object sender, EventArgs e)
        {
            Operator_click('x');
        }

        private void button_divide_Click(object sender, EventArgs e)
        {
            Operator_click('/');
        }

        private void button_equal_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(temporary_value);
            if (operator_name != '%' && operator_name != '^')
            {
                value_two = Convert.ToDouble(temporary_value);

            }
           
            switch (operator_name)
            {
                case '+':
                    answer_display.Text = (value_one + value_two).ToString();
                    break;
                case '-':
                    answer_display.Text = (value_one - value_two).ToString();
                    break;
                case 'x':
                    answer_display.Text = (value_one * value_two).ToString();
                    break;
                case '/':
                    answer_display.Text = (value_one / value_two).ToString();
                    break;
                case '%':
                    answer_display.Text =(value_one / 100).ToString();
                    break;
                case '^':
                    answer_display.Text = (value_one * value_one).ToString();
                    break;
                default:
                    break;

            }
           
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            temporary_value = "";
            expression.Text = "";
            answer_display.Text = "";
            operator_name = ' ';
        }

        private void delete_Click(object sender, EventArgs e)
        {
            expression.Text = expression.Text.Substring(0, expression.Text.Length - 1);
            temporary_value = temporary_value.Substring(0, temporary_value.Length - 1);
        }

        private void percentage_Click(object sender, EventArgs e)
        {
            Operator_click('%');
        }

        private void square_Click(object sender, EventArgs e)
        {
            Operator_click('^');
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
